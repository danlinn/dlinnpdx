<?php
   class Redux_Customizer_Control_text extends Redux_Customizer_Control {
     public $type = "redux-text";
   }
<?php
   class Redux_Customizer_Control_textarea extends Redux_Customizer_Control {
     public $type = "redux-textarea";
   }
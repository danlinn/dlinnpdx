<?php
   class Redux_Customizer_Control_typography extends Redux_Customizer_Control {
     public $type = "redux-typography";
   }